"# New_graphql_sample" 

"# Graph Ql sample"

"# Plus base app react native as side menu and tabs"

"# Hasura login navin@abc.com - 12345"

"# Clone app - yarn - yarn start"
